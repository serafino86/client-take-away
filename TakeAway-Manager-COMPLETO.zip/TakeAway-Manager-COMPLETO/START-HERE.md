# 🚀 TAKEAWAY MANAGER - INIZIA QUI!

## ⚡ **QUICK START (10 MINUTI)**

Hai scaricato tutto! Ecco cosa fare:

---

## 📦 **COSA C'È NEL PACCHETTO:**

```
TakeAway-Manager-COMPLETO/
├── 📄 Code-ULTIMATE.gs          ← Backend (Google Apps Script)
├── 📄 index.html                ← App Cliente (mobile)
├── 📄 dashboard.html            ← Dashboard Esercente
├── 📖 README-INSTALLAZIONE.md   ← Guida completa
└── 📖 START-HERE.md             ← Questa guida rapida
```

---

## ✅ **INSTALLAZIONE VELOCE:**

### **STEP 1: BACKEND (3 min)**

1. **Apri Google Sheet:**
   - Vai a: https://docs.google.com/spreadsheets/d/1nxD5HTjbvEApBYyeDNNpnBnpbM87Gey-FsxydYV4JJk/edit
   - **O crea nuovo:** https://sheets.google.com → "+ Blank"

2. **Apri Apps Script:**
   - Nel Google Sheet: **Estensioni** → **Apps Script**

3. **Incolla backend:**
   - Apri `Code-ULTIMATE.gs` in un editor di testo
   - Copia TUTTO il contenuto (Ctrl+A, Ctrl+C)
   - Torna ad Apps Script
   - Cancella codice esistente (Ctrl+A, Delete)
   - Incolla (Ctrl+V)
   - **Salva** (Ctrl+S)

4. **Esegui setup:**
   - Dropdown funzioni → **INIZIO**
   - Click ▶️ **Run**
   - Autorizza permessi (prima volta)
   - Attendi 10 secondi

5. **Verifica sheets creati:**
   - Torna al Google Sheet
   - F5 (refresh)
   - Vedi 5 tabs colorati in basso ✅

6. **Deploy API:**
   - Apps Script → **Deploy** → **New deployment**
   - Type: **Web app**
   - Who has access: **Anyone** ⚠️
   - **Deploy** → Copia URL

✅ **Backend pronto!**

---

### **STEP 2: TEST APP CLIENTE (2 min)**

1. **Apri index.html nel browser:**
   - Doppio click su `index.html`
   - Oppure: Trascina in Chrome/Firefox

2. **Verifica funzionamento:**
   - Vedi 15 prodotti caricati? ✅
   - Prova cambio lingua (IT/DE/FR)
   - Aggiungi prodotto al carrello
   - Scrivi nota: "Senza aglio"
   - Compila dati e invia ordine

3. **Controlla Google Sheet:**
   - Tab **Ordini** → Vedi il tuo ordine! ✅
   - Colonna **Note** → Vedi "Senza aglio"! ✅

✅ **App Cliente funziona!**

---

### **STEP 3: TEST DASHBOARD (2 min)**

1. **Apri dashboard.html nel browser:**
   - Doppio click su `dashboard.html`

2. **Verifica 3 tabs:**
   - **Tab ORDINI** → Vedi ordine appena creato
   - **Tab PRODOTTI** → Vedi 15 prodotti
   - **Tab CLIENTI VIP** → Vedi 3 clienti esempio

3. **Prova gestione prodotti:**
   - Tab Prodotti → Modifica prezzo
   - Salva
   - Google Sheet → Tab Prodotti → Vedi modifica! ✅

✅ **Dashboard funziona!**

---

## 🎯 **CONFIGURAZIONE GIÀ FATTA:**

### **✅ SPREADSHEET_ID (nel backend):**
```javascript
const SPREADSHEET_ID = '1nxD5HTjbvEApBYyeDNNpnBnpbM87Gey-FsxydYV4JJk';
```

### **✅ API_URL (in index.html e dashboard.html):**
```javascript
API_URL: 'https://script.google.com/macros/s/AKfycbz51mANUO2Z1CVlsMjzqAoneeAVmx3gYuOaK7zk_pqP1OhAiuB2IZlccGTcJQbQgGES/exec'
```

**Se hai deployato un NUOVO backend con URL diverso:**
1. Apri `index.html` in editor testo
2. Trova riga 924: `API_URL:`
3. Sostituisci con il TUO URL
4. Salva
5. Ripeti per `dashboard.html` (riga 1009)

---

## 🔍 **TROUBLESHOOTING:**

### **❌ Prodotti non si caricano**
→ Controlla API_URL in index.html (riga 924)
→ Test API browser: `[URL]?action=getProdotti`

### **❌ Errore "openById"**
→ SPREADSHEET_ID sbagliato nel backend
→ Copia ID dall'URL del Google Sheet

### **❌ Errore 403**
→ Deploy Web App: "Who has access" deve essere **Anyone**

### **❌ Note non si salvano**
→ Backend già fixato, verifica versione Code-ULTIMATE.gs

---

## 📁 **STRUTTURA PROGETTO:**

```
Backend (Google Apps Script):
├── Code-ULTIMATE.gs (1595 righe)
├── 33 funzioni
├── Setup automatico INIZIO()
├── Test automatici TEST()
└── 15 prodotti esempio

Frontend Cliente:
├── index.html (1606 righe)
├── Multilingua IT/DE/FR
├── Sistema VIP
├── Carrello live
├── Note cliente
└── Pagamento Stripe/Cash

Frontend Esercente:
├── dashboard.html (1605 righe)
├── Tab Ordini (filtri pranzo/cena)
├── Tab Prodotti (CRUD completo)
├── Tab Clienti VIP
└── Stats real-time
```

---

## ✅ **CHECKLIST RAPIDA:**

- [ ] Backend incollato in Apps Script
- [ ] INIZIO() eseguito
- [ ] 5 sheets creati e visibili
- [ ] Deploy Web App fatto
- [ ] URL API copiato
- [ ] index.html aperto → Prodotti caricati
- [ ] Ordine test → Salvato con note
- [ ] dashboard.html aperto → Ordini visibili
- [ ] Prodotto modificato → Salvato

---

## 🎉 **TUTTO FUNZIONA?**

**HAI ORA:**
- ✅ Backend API funzionante
- ✅ Database Google Sheets
- ✅ App cliente mobile
- ✅ Dashboard esercente
- ✅ 15 prodotti esempio
- ✅ Sistema VIP
- ✅ Auto-traduzione IT/DE/FR
- ✅ ZERO costi mensili

---

## 📚 **PROSSIMI STEP:**

1. **Personalizza:**
   - Logo ristorante
   - Colori brand
   - Testi menu

2. **Deploy online:**
   - Netlify (gratis)
   - Vercel (gratis)
   - GitHub Pages

3. **Leggi guida completa:**
   - Apri `README-INSTALLAZIONE.md`
   - Documentazione API
   - Features avanzate

---

## 🆘 **SERVE AIUTO?**

- **Guida completa:** Vedi `README-INSTALLAZIONE.md`
- **Email:** enrico@serafinoresout.ch

---

**Made with ❤️ by SERAFINO RÉSOUT**

**VERSION:** 2.0 ULTIMATE COMPLETE  
**DATE:** January 2025  
**STATUS:** ✅ PRODUCTION READY

---

## 🚀 **BUON LAVORO!**

Hai tutto il necessario per iniziare.
Il sistema è completo e funzionante.

**In bocca al lupo! 🍀**
