# 🧪 GUIDA APP DEBUG - TEST COMPLETO SISTEMA

**Data:** 25 Gennaio 2026  
**Versione:** Debug Apps v1.0

---

## 🎯 **2 APP DEBUG:**

### **1. DEBUG-APP-ORDINI.html** 🛒
Testa creazione ordini cliente:
- Ordini VIP
- Ordini Guest  
- Ordini futuri (domani/dopodomani/+2/+3)
- Stress test 10 ordini
- Orari diversi (pranzo/stasera/cena)

### **2. DEBUG-APP-DASHBOARD.html** 📊
Testa visualizzazione dashboard:
- Carica ordini da API
- Filtro OGGI
- Filtro STASERA (≥17:00)
- Filtro DOMANI
- Ordini da ORA in poi

---

## 🚀 **DEPLOYMENT:**

### **Upload su GitHub:**
```
1. GitHub → Repository takeaway-manager
2. Upload:
   📄 DEBUG-APP-ORDINI.html
   📄 DEBUG-APP-DASHBOARD.html
3. Commit: "Add debug apps"
4. Aspetta 1-2 min
```

### **Oppure Test Locale:**
```
Apri direttamente i file HTML nel browser
(Già configurati con API_URL)
```

---

## 📋 **WORKFLOW TEST COMPLETO:**

### **STEP 1: Crea Ordini Test (15 min)**

```
1. Apri: DEBUG-APP-ORDINI.html

2. Verifica API URL (già configurato)

3. Click "⚡ ESEGUI TUTTI I TEST"

4. Attendi completamento (~3 minuti)

5. Vedi statistiche:
   Ordini Totali: ~18
   ✅ Successi: 18
   ❌ Errori: 0
```

**Cosa crea:**
- 1 ordine VIP
- 1 ordine Guest
- 4 ordini futuri (domani/dopodomani/+2/+3)
- 3 ordini orari diversi (12:00/17:30/20:00)
- 10 ordini stress test

**Totale: ~18 ordini**

---

### **STEP 2: Verifica Google Sheet (2 min)**

```
1. Apri Google Sheet

2. Tab "Ordini"

3. Verifica ~18 righe nuove

4. Controlla colonne:
   - ID univoci ✅
   - Date corrette (oggi/domani/+2/+3) ✅
   - Orari diversi (12:00/17:30/20:00) ✅
   - Clienti (VIP/Guest/Test) ✅
   - Prodotti JSON ✅
   - Note presenti ✅
   - Totali corretti ✅
```

---

### **STEP 3: Test Dashboard (10 min)**

```
1. Apri: DEBUG-APP-DASHBOARD.html

2. Verifica API URL

3. Click "⚡ ESEGUI TUTTI I TEST"

4. Vedi statistiche aggiornate:
   Totali: 18
   Oggi: ~14 (VIP + Guest + orari + stress)
   Stasera: ~1 (ordine 17:30)
   Domani: 1
   Futuri: 3 (+2gg, +3gg, +4gg)
```

**Test eseguiti:**
- ✅ Carica tutti ordini
- ✅ Filtro OGGI → mostra solo oggi
- ✅ Filtro STASERA → mostra solo ≥17:00
- ✅ Filtro DOMANI → mostra solo domani
- ✅ Da ORA → mostra solo orari futuri

---

### **STEP 4: Test Dashboard Reale (5 min)**

```
1. Apri Dashboard vera:
   https://serafino86.github.io/takeaway-manager/dashboard.html

2. Login admin

3. Tab "Ordini"

4. Vedi ~18 ordini ✅

5. Click "☀️ Oggi"
   → Vedi ~14 ordini ✅

6. Click "🌙 Stasera"
   → Vedi 1 ordine (17:30) ✅

7. Click "📅 Domani"
   → Vedi 1 ordine ✅

8. Aspetta 30 secondi
   → Auto-refresh funziona ✅
```

---

## 🧪 **TEST INDIVIDUALI:**

### **Test 1: Ordine VIP**
```
DEBUG-APP-ORDINI → Click "▶️ Ordine Cliente VIP"

✅ Ordine creato
✅ Cliente: Marco Bianchi
✅ Email: marco.bianchi@vip.ch
✅ VIP: true
✅ VIP Level: Gold
✅ Note: Cliente VIP - Servizio prioritario
```

### **Test 2: Ordine Guest**
```
DEBUG-APP-ORDINI → Click "▶️ Ordine Ospite Anonimo"

✅ Ordine creato
✅ Cliente: Ospite
✅ Guest: true
✅ No email/telefono
```

### **Test 3: Ordini Futuri**
```
DEBUG-APP-ORDINI → Click "▶️ Domani + Dopodomani + +2gg + +3gg"

✅ 4 ordini creati
✅ Date: domani, dopodomani, +2gg, +3gg
✅ Tutti orario 12:00
```

### **Test 4: Stress Test**
```
DEBUG-APP-ORDINI → Click "🔥 10 Ordini Rapidi"

✅ 10 ordini creati in ~5 secondi
✅ Orari: 12:00, 12:30, 13:00, ..., 16:30
✅ Clienti: StressTest-1 ... StressTest-10
```

### **Test 5: Orari Diversi**
```
DEBUG-APP-ORDINI → Click "▶️ Pranzo + Stasera + Cena"

✅ 3 ordini creati
✅ 12:00 (PRANZO)
✅ 17:30 (STASERA)
✅ 20:00 (CENA)
```

---

## 📊 **VERIFICA FILTRI DASHBOARD:**

### **Filtro OGGI:**
```
Dashboard → "☀️ Oggi"

Deve mostrare:
- Ordine VIP (oggi 12:30)
- Ordine Guest (oggi 13:00)
- 3 ordini orari (12:00/17:30/20:00)
- 10 ordini stress test

Totale: ~14 ordini ✅
```

### **Filtro STASERA:**
```
Dashboard → "🌙 Stasera"

Deve mostrare:
- Ordine 17:30
- Ordine 20:00 (se oggi)

Totale: 1-2 ordini ✅
```

### **Filtro DOMANI:**
```
Dashboard → "📅 Domani"

Deve mostrare:
- 1 ordine domani 12:00

Totale: 1 ordine ✅
```

### **Da ORA in poi:**
```
DEBUG-APP-DASHBOARD → Test "🕐 Ordini da ORA"

Se sono le 15:00:
- Mostra ordini ≥15:00
- NON mostra ordini 12:00, 12:30, 13:00

✅ Filtro temporale funziona
```

---

## 🎯 **CHECKLIST COMPLETA:**

**Creazione Ordini:**
- [ ] Ordine VIP creato
- [ ] Ordine Guest creato
- [ ] 4 ordini futuri creati
- [ ] 10 ordini stress test creati
- [ ] 3 ordini orari diversi creati
- [ ] Google Sheet ha ~18 ordini

**Visualizzazione Dashboard:**
- [ ] Carica tutti ordini (18)
- [ ] Filtro OGGI mostra ~14
- [ ] Filtro STASERA mostra 1-2
- [ ] Filtro DOMANI mostra 1
- [ ] Da ORA filtra correttamente
- [ ] Auto-refresh funziona (30s)

**Dashboard Reale:**
- [ ] Tab Ordini carica dati
- [ ] Filtri temporali funzionano
- [ ] Card ordini mostrano prodotti
- [ ] Note visibili se presenti
- [ ] Totali corretti
- [ ] Bottone Archivia presente

---

## 🔧 **TROUBLESHOOTING:**

### **Errore: "CORS blocked"**
```
Soluzione:
- Upload su GitHub Pages
- NON testare da file:///
```

### **Errore: "0 ordini creati"**
```
Verifica:
1. API_URL corretto
2. Backend deployato
3. F12 → Console per errori
```

### **Dashboard non mostra ordini**
```
Verifica:
1. DEBUG-APP-DASHBOARD carica ordini? 
2. Colonna "Archiviato" vuota su Sheet?
3. F12 → Console per errori
```

### **Filtro STASERA vuoto**
```
Normale se:
- Ora attuale < 17:00
- Nessun ordine oggi ≥17:00

Soluzione:
- DEBUG-APP-ORDINI → Test Orari Diversi
- Crea ordine 17:30
```

---

## 📸 **SCREENSHOT ATTESI:**

### **DEBUG-APP-ORDINI dopo Full Test:**
```
📊 Statistiche Test
   Ordini Creati: 18
   ✅ Successi: 18
   ❌ Errori: 0
```

### **DEBUG-APP-DASHBOARD dopo Full Test:**
```
📊 Statistiche Ordini
   Totali: 18
   Oggi: 14
   Stasera: 1
   Domani: 1
   Futuri: 3
```

### **Google Sheet Tab Ordini:**
```
~18 righe con:
- ID: 1, 2, 3, ..., 18
- Date: oggi (14), domani (1), +2gg (1), +3gg (1), +4gg (1)
- Orari: 12:00, 12:30, 13:00, 17:30, 20:00, etc.
- Clienti: Marco Bianchi (VIP), Ospite (Guest), StressTest-1...10
```

---

## 🎉 **RISULTATO FINALE:**

Dopo aver eseguito tutti i test:

✅ **Sistema Ordini:** Funziona al 100%  
✅ **Salvataggio:** Tutti ordini su Google Sheet  
✅ **Dashboard:** Carica e filtra correttamente  
✅ **Filtri Temporali:** OGGI/STASERA/DOMANI OK  
✅ **Auto-Refresh:** Aggiorna ogni 30s  
✅ **Stress Test:** 10 ordini simultanei OK  

---

**ESEGUI I TEST E VERIFICA! 🚀**

---

**Versione:** Debug Apps v1.0  
**Data:** 25 Gennaio 2026
