# 🔧 CONFIGURAZIONE SISTEMA

## 📋 **INFORMAZIONI CONFIGURATE:**

### **Google Sheet:**
- **ID:** `1nxD5HTjbvEApBYyeDNNpnBnpbM87Gey-FsxydYV4JJk`
- **URL:** https://docs.google.com/spreadsheets/d/1nxD5HTjbvEApBYyeDNNpnBnpbM87Gey-FsxydYV4JJk/edit

### **API Backend:**
- **URL:** `https://script.google.com/macros/s/AKfycbz51mANUO2Z1CVlsMjzqAoneeAVmx3gYuOaK7zk_pqP1OhAiuB2IZlccGTcJQbQgGES/exec`
- **Configurato in:**
  - `Code-ULTIMATE.gs` → riga 224 (SPREADSHEET_ID)
  - `index.html` → riga 924 (API_URL)
  - `dashboard.html` → riga 1009 (API_URL)

---

## 🔄 **SE HAI CREATO UN NUOVO BACKEND:**

### **1. Ottieni nuovo URL:**
Apps Script → Deploy → New deployment → Copia URL

### **2. Sostituisci in index.html:**
```javascript
// Riga 924
const CONFIG = {
    API_URL: 'IL_TUO_NUOVO_URL_QUI',
    ...
}
```

### **3. Sostituisci in dashboard.html:**
```javascript
// Riga 1009
const API_URL = 'IL_TUO_NUOVO_URL_QUI';
```

---

## 🧪 **TEST URL API:**

Apri nel browser:
```
[TUO_URL]?action=getProdotti
```

Dovresti vedere JSON con 15 prodotti.

---

## 📊 **SHEETS CREATI:**

1. **Ordini** (colonna 9 = Note cliente)
2. **Prodotti** (colonna 11 = Giorno)
3. **Clienti_VIP** (3 clienti esempio)
4. **Config** (8 parametri)
5. **Archivio** (ordini >30 giorni)

---

## 🎯 **ENDPOINT API DISPONIBILI:**

### **GET:**
- `?action=getProdotti`
- `?action=getOrdini`
- `?action=getConfig`
- `?action=getClientiVIP`
- `?action=getProdottiPerCategoria`
- `?action=getPublicConfig`
- `?action=getMenuData`

### **POST:**
- `?action=creaOrdine`
- `?action=registraVIP`
- `?action=loginVIP`
- `?action=aggiungiProdotto`
- `?action=modificaProdotto`
- `?action=eliminaProdotto`
- `?action=aggiornaConfig`
- `?action=impostaDisponibilita`
- `?action=loginAdmin`
- `?action=logoutAdmin`
- `?action=cambiaPasswordAdmin`

---

## 🔐 **CREDENZIALI VIP ESEMPIO:**

| Email | Password | Ordini |
|-------|----------|--------|
| mario@email.com | password | 3 |
| laura@email.com | password | 8 |
| giovanni@email.com | password | 12 |

**Nota:** Password sono in base64, usa "password" per testare.

---

## 🎨 **PERSONALIZZAZIONE:**

### **Cambia colori:**
`index.html` e `dashboard.html` → Cerca `#667eea` (colore primario)

### **Cambia nome ristorante:**
Google Sheet → Tab **Config** → Riga "nomeRistorante"

### **Cambia WhatsApp:**
Google Sheet → Tab **Config** → Riga "whatsapp"

---

## ✅ **VERSIONI FILE:**

- **Code-ULTIMATE.gs:** v2.0 (1595 righe)
- **index.html:** v2.0 (1606 righe)
- **dashboard.html:** v2.0 (1605 righe)

---

**Ultimo aggiornamento:** January 2025
