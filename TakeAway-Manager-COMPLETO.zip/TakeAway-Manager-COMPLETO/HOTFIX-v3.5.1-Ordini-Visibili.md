# 🔥 HOTFIX CRITICO - Ordini non visibili v3.5.1

## ❌ **IL PROBLEMA:**

**Ordini creati da App Cliente NON apparivano nella Dashboard!**

---

## 🔍 **ROOT CAUSE:**

### **Backend creaOrdine():**
```javascript
// PRIMA (12 colonne):
const newRow = [
  orderId,
  pickupDate,
  ...
  'DA_PREPARARE',
  new Date().toISOString()
  // ❌ Manca colonna 13 (Archiviato)
];
```

### **Backend getOrdini():**
```javascript
archiviato: row[13] === 'ARCHIVIATO'  // ✅ Legge colonna 13
```

### **Filtro Dashboard:**
```javascript
ordini = ordini.filter(o => !o.archiviato);
// Se row[13] è undefined → !undefined = true
// Ordine NON filtrato ✅

// MA se Google Sheets compatta colonne...
// row[13] potrebbe essere null/undefined
// E filtro potrebbe comportarsi stranamente
```

**PROBLEMA:** Colonna 13 mancante causava comportamento inconsistente!

---

## ✅ **FIX APPLICATO:**

```javascript
// DOPO (13 colonne):
const newRow = [
  orderId,
  pickupDate,
  ...
  'DA_PREPARARE',
  new Date().toISOString(),
  ''  // ✅ Colonna 13: Archiviato (vuoto = non archiviato)
];
```

**Ora:**
- Nuovi ordini hanno colonna 13 = `''` (vuoto)
- `row[13] === 'ARCHIVIATO'` → false
- `!o.archiviato` → true
- **Ordine VISIBILE in Dashboard** ✅

---

## 🚀 **DEPLOYMENT HOTFIX:**

### **STEP 1: Backend**
```
1. Apps Script → Code.gs

2. Sostituisci con Code-ULTIMATE.gs ☝️

3. Salva (Ctrl+S)

4. Deploy → Manage deployments
   → Edit deployment esistente
   → New version: "v3.5.1 - Fix ordini visibili"
   → Deploy

5. Conferma URL resta:
   https://script.google.com/macros/s/AKfycbyaILtuVI45Zmj0IYlNC4DV5Z4_EMUCkYx_d9rPqE7vg1lF75ANNUWJvUWALxLlNn6P/exec
```

---

## 🧪 **TEST IMMEDIATO:**

### **Test 1: Crea Ordine**
```
1. App Cliente → Aggiungi prodotto

2. Compila dati cliente

3. Conferma ordine

4. Nota ID ordine (es. #1050)
```

### **Test 2: Verifica Dashboard**
```
1. Dashboard → Tab "Comande"

2. CTRL + F5 (hard refresh)

3. VERIFICA:
   - Ordine #1050 VISIBILE ✅
   - Badge stato presente ✅
   - Bottoni funzionanti ✅
```

### **Test 3: Verifica Google Sheet**
```
1. Google Sheet → Tab "Ordini"

2. Trova riga ordine #1050

3. VERIFICA:
   - Colonna M (13): VUOTA ✅
   - Colonna A-L: Dati corretti ✅
```

---

## 📊 **STRUTTURA SHEET CORRETTA:**

| A | B | C | D | E | F | G | H | I | J | K | L | M |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ID | Data | Ora | Nome | Tel | Email | VIP | Prodotti | Note | Totale | Pag | Stato | **Archiviato** |
| 1050 | 2026-01-26 | 12:00 | Mario | 079... | ... | NO | [...] | Test | 25.00 | later | DA_PREPARARE | **(vuoto)** |

**Colonna M = Archiviato:**
- Vuoto = Ordine attivo (visibile)
- "ARCHIVIATO" = Ordine archiviato (nascosto)

---

## 🔧 **SE ORDINI VECCHI NON VISIBILI:**

### **Fix Manuale Google Sheet:**
```
1. Google Sheet → Tab "Ordini"

2. Seleziona colonna M (Archiviato)

3. Per OGNI riga ordine:
   - Se vuoi vederlo → LASCIA VUOTO
   - Se vuoi nasconderlo → Scrivi "ARCHIVIATO"

4. Dashboard → Refresh → Ordini visibili ✅
```

---

## 💡 **PREVENZIONE FUTURA:**

### **Sempre verificare numero colonne:**
```javascript
// creaOrdine()
const newRow = [
  // ... 12 campi ...
  lastField,
  ''  // ✅ Sempre aggiungere colonna Archiviato
];

// getOrdini()
archiviato: row[13] === 'ARCHIVIATO'
// ✅ Colonna 13 deve esistere
```

---

## 📋 **CHECKLIST DEPLOYMENT:**

**Backend:**
- [ ] Code-ULTIMATE.gs con fix colonna 13
- [ ] Deploy → Edit deployment esistente
- [ ] URL Production confermato

**Test:**
- [ ] Crea ordine da app cliente
- [ ] Verifica visibile in dashboard
- [ ] Verifica Google Sheet colonna M
- [ ] Test bottone "Completato"
- [ ] Verifica ordine archiviato sparisce

---

## 🎯 **WORKFLOW COMPLETO DOPO FIX:**

```
1. CLIENTE:
   App Cliente → Crea ordine #1050

2. BACKEND:
   creaOrdine() → Salva con colonna 13 = ''

3. GOOGLE SHEET:
   Riga aggiunta con 13 colonne ✅

4. DASHBOARD:
   getOrdini() → row[13] === 'ARCHIVIATO' → false
   !o.archiviato → true
   Ordine #1050 VISIBILE ✅

5. RISTORANTE:
   Click "✓ Completato"
   archiviaOrdine() → Imposta colonna 13 = 'ARCHIVIATO'

6. DASHBOARD:
   getOrdini() → row[13] === 'ARCHIVIATO' → true
   !o.archiviato → false
   Ordine #1050 NASCOSTO ✅
```

---

## ⚠️ **NOTA IMPORTANTE:**

Questo fix è **CRITICO** per il funzionamento del sistema!

Senza colonna 13 nei nuovi ordini:
- ❌ Ordini potrebbero non apparire
- ❌ Filtro archiviati inconsistente
- ❌ Dashboard vuota anche con ordini attivi

Con fix:
- ✅ Tutti gli ordini visibili
- ✅ Archiviazione funzionante
- ✅ Sistema stabile

---

**DEPLOY IMMEDIATAMENTE! 🚨**

---

**Versione:** v3.5.1 - Hotfix Ordini Visibili  
**Data:** 26 Gennaio 2026  
**Priority:** 🔥 CRITICO  
**Status:** ✅ FIXATO - Deploy richiesto
