# ⚡ GUIDA RAPIDA DEPLOYMENT

**API URL Nuovo:** 
```
https://script.google.com/macros/s/AKfycbw8NDGmaejmg9owPv7RCmpqGnj0I0l11S6JTy50DyVxCFOACNZ1cNOXARlUKEi90l9r/exec
```

---

## 🚀 **3 STEP DEPLOYMENT:**

### **1️⃣ Backend (Apps Script)**

```
✅ GIÀ DEPLOYATO!
URL: ...AKfycbw8NDGm...exec

Google Sheet già creato con 17 colonne!
```

---

### **2️⃣ Frontend (GitHub) - FAI QUESTO ORA:**

```
1. GitHub → Repository: takeaway-manager

2. Upload 2 file:
   📄 index.html (nel ZIP)
   📄 dashboard.html (nel ZIP)

3. Commit: "v3.0: Sistema checkboxes - FINALE"

4. Aspetta 1-2 minuti

5. Hard refresh (CTRL + F5):
   - https://serafino86.github.io/takeaway-manager/index.html
   - https://serafino86.github.io/takeaway-manager/dashboard.html
```

---

### **3️⃣ Test (1 minuto)**

**Dashboard:**
```
1. Vai a: https://serafino86.github.io/takeaway-manager/dashboard.html
2. Login admin
3. Tab "Prodotti"
4. Vedi checkboxes LUN/MAR/MER/GIO/VEN/SAB/DOM? ✅
5. Click checkbox LUN → Si attiva
6. Toast: "✅ LUNEDI: Attivo"
7. Google Sheet → Colonna K (LUN) = SI ✅
```

**App Cliente:**
```
1. Vai a: https://serafino86.github.io/takeaway-manager/index.html
2. Sezione "OGGI"
3. Vedi prodotti disponibili oggi? ✅
4. Click "Menu Settimanale"
5. Click tab "Lunedì"
6. Vedi solo prodotti con LUN=SI? ✅
```

---

## ✅ **TUTTO CONFIGURATO:**

✅ API_URL aggiornato in tutti i file  
✅ Backend deployato  
✅ Google Sheet pronto con 17 colonne  
✅ Frontend pronto per upload  

---

## 🎯 **COSA HAI NEL ZIP:**

1. **Code-ULTIMATE.gs** → Backend (già su Apps Script)
2. **index.html** → App cliente (da uploadare su GitHub)
3. **dashboard.html** → Dashboard (da uploadare su GitHub)
4. **SUPER-DEBUG.html** → Tool debug (opzionale)
5. **MEGA-DEBUG.html** → Tool debug (opzionale)
6. **DEPLOYMENT-FINALE.md** → Guida completa

---

## 🔧 **SE HAI PROBLEMI:**

### **Dashboard non carica prodotti:**
```
F12 → Console → Vedi errori?

Se "CORS error":
→ Hard refresh: CTRL + F5

Se "404 Not Found":
→ Verifica API_URL in dashboard.html riga ~920
```

### **App cliente non mostra prodotti OGGI:**
```
1. Google Sheet → Tab Prodotti
2. Verifica che prodotti hanno almeno 1 giorno = SI
3. Verifica colonna Disponibile = SI
```

### **Checkboxes non salvano:**
```
Dashboard → F12 → Console
Click checkbox → Vedi:
"📅 lunedi: SI"
"📤 Invio POST: ..."
"✅ Risposta API: {success: true}"

Se non vedi nulla:
→ CTRL + F5 (hard refresh)
```

---

## 📸 **SCREENSHOT ATTESI:**

**Dashboard - Card Prodotto:**
```
┌─────────────────────────────────┐
│ Lasagne al Forno    CHF 16.50  │
│ Primo - Disponibile             │
│                                 │
│ 📅 Disponibilità Settimanale    │
│ ☑ LUN ☑ MAR ☑ MER ☑ GIO ☑ VEN │
│ ☐ SAB ☐ DOM                    │
│                                 │
│ [✓ Tutti giorni lavorativi]    │
└─────────────────────────────────┘
```

**Google Sheet:**
```
| ID | Nome    | ... | LUN | MAR | MER | GIO | VEN | SAB | DOM |
|----|---------|-----|-----|-----|-----|-----|-----|-----|-----|
| 1  | Lasagne | ... | SI  | SI  | SI  | SI  | SI  | NO  | NO  |
```

---

## 🎉 **PRONTO!**

**Upload su GitHub e testa! 🚀**

---

**URL Deployment:** https://script.google.com/macros/s/AKfycbw8NDGmaejmg9owPv7RCmpqGnj0I0l11S6JTy50DyVxCFOACNZ1cNOXARlUKEi90l9r/exec
